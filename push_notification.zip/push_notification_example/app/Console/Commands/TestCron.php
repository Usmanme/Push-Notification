<?php

namespace App\Console\Commands;

use App\Models\User;
use App\Services\SendNotificationService;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Mail;

class TestCron extends Command
{
    /**
     * The name and signature of the console command.
     *
     * @var string
     */
    protected $signature = 'test:cron';

    /**
     * The console command description.
     *
     * @var string
     */
    protected $description = 'Command description';

    /**
     * Execute the console command.
     *
     * @return int
     */
    public function handle()
    {
        // $data= array('data'=>'JSK Admin Here!...');
        // Mail::send('mail',$data, function($message){
        //     $message->to('usman.islootech@gmail.com')
        //     ->subject('Crone Job Testing');
        // });
        SendNotificationService::sendNotification();
        // return Command::SUCCESS;
    }
}